package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.foundation.isSystemInDarkTheme

private val DarkImmersiveColorScheme =
  darkColorScheme(
    primary = ImmersivePrimary,
    onPrimary = ImmersiveOnPrimary,
    background = ImmersiveBackground,
    surface = ImmersiveSurface,
    surfaceVariant = ImmersiveSurfaceVariant,
    onBackground = ImmersiveOnBackground,
    onSurface = ImmersiveOnBackground,
    onSurfaceVariant = ImmersiveOnBackground,
    errorContainer = ImmersiveSurfaceVariant,
    onErrorContainer = ImmersiveOnBackground
  )

private val LightImmersiveColorScheme =
  lightColorScheme(
    primary = LightImmersivePrimary,
    onPrimary = LightImmersiveOnPrimary,
    background = LightImmersiveBackground,
    surface = LightImmersiveSurface,
    surfaceVariant = LightImmersiveSurfaceVariant,
    onBackground = LightImmersiveOnBackground,
    onSurface = LightImmersiveOnBackground,
    onSurfaceVariant = LightImmersiveOnBackground,
    errorContainer = LightImmersiveSurfaceVariant,
    onErrorContainer = LightImmersiveOnBackground
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  content: @Composable () -> Unit,
) {
  val colorScheme = if (darkTheme) DarkImmersiveColorScheme else LightImmersiveColorScheme

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
