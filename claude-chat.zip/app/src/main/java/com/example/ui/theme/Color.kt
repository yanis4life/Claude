package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val ImmersiveBackground = Color(0xFF1C1B1F)
val ImmersiveSurface = Color(0xFF1C1B1F)
val ImmersiveSurfaceVariant = Color(0xFF49454F) 
val ImmersivePrimary = Color(0xFFD0BCFF)
val ImmersiveOnPrimary = Color(0xFF381E72)
val ImmersiveOnBackground = Color(0xFFE6E1E5)

val LightImmersiveBackground = Color(0xFFFDFBFE)
val LightImmersiveSurface = Color(0xFFFDFBFE)
val LightImmersiveSurfaceVariant = Color(0xFFE7E0EC)
val LightImmersivePrimary = Color(0xFF6750A4)
val LightImmersiveOnPrimary = Color(0xFFFFFFFF)
val LightImmersiveOnBackground = Color(0xFF1C1B1F)

val ImmersiveInputBackground = Color(0xFF2B2930)
val LightImmersiveInputBackground = Color(0xFFF3EDF7)
val ImmersiveMuted = Color(0xFF938F99)
val LightImmersiveMuted = Color(0xFF49454F)
val ImmersiveSubtext = Color(0xFFCAC4D0)
val LightImmersiveSubtext = Color(0xFF49454F)
