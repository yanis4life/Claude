package com.example

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.ChatMessage
import com.example.data.ChatRepository
import com.example.data.User
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val client = OkHttpClient()
    private val repository: ChatRepository

    init {
        val chatDao = AppDatabase.getDatabase(application).chatDao()
        repository = ChatRepository(chatDao)
    }

    private val _currentUser = MutableStateFlow<User?>(null)
    val currentUser = _currentUser.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val messages: StateFlow<List<ChatMessage>> = combine(_currentUser, _searchQuery) { user, query ->
        Pair(user, query)
    }.flatMapLatest { (user, query) ->
        if (user != null) {
            if (query.isBlank()) {
                repository.getMessagesForUser(user.id)
            } else {
                repository.searchMessagesForUser(user.id, query)
            }
        } else {
            flowOf(emptyList())
        }
    }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    private val _isLoading = MutableStateFlow(false)
    val isLoading = _isLoading.asStateFlow()

    private val _authError = MutableStateFlow<String?>(null)
    val authError = _authError.asStateFlow()

    fun clearAuthError() {
        _authError.value = null
    }

    fun login(email: String, passwordHash: String) {
        viewModelScope.launch {
            val user = repository.getUserByEmail(email)
            if (user != null && user.passwordHash == passwordHash) {
                _currentUser.value = user
            } else {
                _authError.value = "Invalid email or password"
            }
        }
    }

    fun signUp(email: String, passwordHash: String) {
        viewModelScope.launch {
            val existing = repository.getUserByEmail(email)
            if (existing != null) {
                _authError.value = "User already exists"
                return@launch
            }
            val newUser = User(email = email, passwordHash = passwordHash)
            val id = repository.insertUser(newUser)
            _currentUser.value = newUser.copy(id = id.toInt())
            
            // Add welcome message
            repository.insertMessage(ChatMessage(userId = id.toInt(), text = "Hello! I am Claude. How can I help you today?", isUser = false))
        }
    }

    fun logout() {
        _currentUser.value = null
        _searchQuery.value = ""
    }
    
    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun sendMessage(text: String) {
        if (text.isBlank()) return
        val user = _currentUser.value ?: return

        viewModelScope.launch {
            repository.insertMessage(ChatMessage(userId = user.id, text = text, isUser = true))
            _isLoading.value = true

            val replyText = try {
                val encodedQuery = withContext(Dispatchers.IO) {
                    URLEncoder.encode(text, "UTF-8")
                }
                val url = "https://kakarotai.rf.gp/api/opus4.7/api.php?question=$encodedQuery"
                val request = Request.Builder().url(url).build()

                val response = withContext(Dispatchers.IO) {
                    client.newCall(request).execute()
                }

                val responseBody = response.body?.string() ?: ""
                try {
                    val json = JSONObject(responseBody)
                    json.optString("response", 
                        json.optString("answer", 
                            json.optString("message", 
                                json.optString("reply", responseBody)
                            )
                        )
                    )
                } catch (e: Exception) {
                    responseBody.ifBlank { "Received an empty response." }
                }
            } catch (e: Exception) {
                e.printStackTrace()
                "Error communicating with Claude. Please try again."
            }

            repository.insertMessage(ChatMessage(userId = user.id, text = replyText, isUser = false, isError = replyText.startsWith("Error")))
            _isLoading.value = false
        }
    }
}
