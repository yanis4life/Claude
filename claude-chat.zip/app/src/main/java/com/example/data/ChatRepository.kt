package com.example.data

import kotlinx.coroutines.flow.Flow

class ChatRepository(private val chatDao: ChatDao) {
    
    suspend fun getUserByEmail(email: String): User? {
        return chatDao.getUserByEmail(email)
    }

    suspend fun insertUser(user: User): Long {
        return chatDao.insertUser(user)
    }

    fun getMessagesForUser(userId: Int): Flow<List<ChatMessage>> {
        return chatDao.getMessagesForUser(userId)
    }

    fun searchMessagesForUser(userId: Int, query: String): Flow<List<ChatMessage>> {
        return chatDao.searchMessagesForUser(userId, query)
    }

    suspend fun insertMessage(message: ChatMessage) {
        chatDao.insertMessage(message)
    }
}
