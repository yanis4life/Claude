package com.colorizer

import android.content.ContentResolver
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Create
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.colorizer.ui.theme.MyApplicationTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

data class DetectedButton(
    val id: String = UUID.randomUUID().toString(),
    val fullStatement: String,
    val type: String,
    val innerContent: String,
    val startIndex: Int,
    val endIndex: Int,
    val selectedColor: String? = null
)

data class PyFile(
    val uri: Uri,
    val name: String,
    val content: String,
    val buttons: List<DetectedButton> = emptyList()
)

class MainViewModel : ViewModel() {
    private val _pyFiles = MutableStateFlow<List<PyFile>>(emptyList())
    val pyFiles: StateFlow<List<PyFile>> = _pyFiles

    private val _outputUri = MutableStateFlow<Uri?>(null)
    val outputUri: StateFlow<Uri?> = _outputUri

    private val _isProcessing = MutableStateFlow(false)
    val isProcessing: StateFlow<Boolean> = _isProcessing

    fun addFiles(uris: List<Uri>, contentResolver: ContentResolver) {
        val newFiles = uris.mapNotNull { uri ->
            val content = readUri(uri, contentResolver) ?: return@mapNotNull null
            val name = getFileName(uri, contentResolver) ?: "unknown_script"
            val buttons = detectButtons(content)
            PyFile(uri = uri, name = name, content = content, buttons = buttons)
        }
        val currentFiles = _pyFiles.value.toMutableList()
        newFiles.forEach { newF ->
            if (currentFiles.none { it.uri == newF.uri }) {
                currentFiles.add(newF)
            }
        }
        _pyFiles.value = currentFiles
    }

    fun setOutputFolder(uri: Uri) {
        _outputUri.value = uri
    }

    fun setGlobalFileColor(fileUri: Uri, color: String?) {
        _pyFiles.value = _pyFiles.value.map { file ->
            if (file.uri == fileUri) {
                file.copy(buttons = file.buttons.map { it.copy(selectedColor = color) })
            } else {
                file
            }
        }
    }

    fun updateButtonColor(fileUri: Uri, buttonId: String, color: String?) {
        _pyFiles.value = _pyFiles.value.map { file ->
            if (file.uri == fileUri) {
                file.copy(buttons = file.buttons.map { btn ->
                    if (btn.id == buttonId) btn.copy(selectedColor = color) else btn
                })
            } else file
        }
    }
    
    fun removeFile(uri: Uri) {
        _pyFiles.value = _pyFiles.value.filter { it.uri != uri }
    }

    fun clearFiles() {
        _pyFiles.value = emptyList()
    }

    fun processAndSave(context: Context, onSuccess: () -> Unit, onError: (String) -> Unit) {
        val folderUri = _outputUri.value
        if (folderUri == null) {
            onError("Please select an output folder first.")
            return
        }
        val currentFiles = _pyFiles.value
        if (currentFiles.isEmpty()) {
            onError("No files selected.")
            return
        }

        viewModelScope.launch {
            _isProcessing.value = true
            try {
                withContext(Dispatchers.IO) {
                    val resolver = context.contentResolver
                    val pickedDir = DocumentFile.fromTreeUri(context, folderUri) 
                        ?: throw Exception("Invalid Output Directory")

                    for (file in currentFiles) {
                        var modifiedContent = file.content
                        val sortedButtons = file.buttons.sortedByDescending { it.startIndex }
                        for (btn in sortedButtons) {
                            val color = btn.selectedColor
                            if (color != null) {
                                val newStatement = when {
                                    btn.type == "PHP_Array" -> {
                                        val cInfo = btn.innerContent.substring(0, btn.innerContent.lastIndexOf(']')).replace(Regex("""\s*,\s*['"]color['"]\s*=>\s*['"][^'"]*['"]"""), "")
                                        "$cInfo, 'color' => '$color']"
                                    }
                                    btn.type == "JS_Object" -> {
                                        val cInfo = btn.innerContent.substring(0, btn.innerContent.lastIndexOf('}')).replace(Regex("""\s*,\s*['"]?color['"]?\s*:\s*['"][^'"]*['"]"""), "")
                                        "$cInfo, color: '$color' }"
                                    }
                                    else -> {
                                        val cleanParams = btn.innerContent.replace(Regex("""\s*,\s*(?:color|style)\s*=\s*['"][^'"]*['"]"""), "")
                                        val newInner = if (cleanParams.isBlank()) "color='$color'" else "$cleanParams, color='$color'"
                                        "${btn.type}($newInner)"
                                    }
                                }
                                modifiedContent = modifiedContent.replaceRange(btn.startIndex, btn.endIndex + 1, newStatement)
                            }
                        }

                        val signature = if (file.name.endsWith(".py")) {
                            "# colorized by https://t.me/XV_YX\n"
                        } else {
                            "// colorized by https://t.me/XV_YX\n"
                        }
                        if (!modifiedContent.contains("colorized by https://t.me/XV_YX")) {
                            modifiedContent = signature + modifiedContent
                        }

                        val mimeType = when {
                            file.name.endsWith(".py") -> "text/x-python"
                            file.name.endsWith(".php") -> "text/x-php"
                            file.name.endsWith(".js") -> "application/javascript"
                            else -> "text/plain"
                        }

                        val nameParts = file.name.split('.')
                        val baseName = if (nameParts.size > 1) nameParts.dropLast(1).joinToString(".") else file.name
                        val ext = if (nameParts.size > 1) ".${nameParts.last()}" else ""
                        val finalName = "colorized_$baseName$ext"

                        val destFile = pickedDir.createFile(mimeType, finalName)
                            ?: pickedDir.createFile(mimeType, file.name)
                            ?: throw Exception("Failed to create file ${file.name}")
                            
                        val destUri = destFile.uri
                        resolver.openOutputStream(destUri)?.use { output ->
                            output.write(modifiedContent.toByteArray())
                        } ?: throw Exception("Failed to write to file ${file.name}")
                    }
                }
                onSuccess()
            } catch (e: Exception) {
                onError("Error: ${e.message}")
            } finally {
                _isProcessing.value = false
            }
        }
    }

    private fun detectButtons(content: String): List<DetectedButton> {
        val buttons = mutableListOf<DetectedButton>()
        
        val pyRegex = Regex("""(InlineKeyboardButton|KeyboardButton|ReplyKeyboardButton)\s*\(\s*((?:[^)(]|\([^)(]*\))*)\)""")
        buttons.addAll(pyRegex.findAll(content).map { match ->
            DetectedButton(
                fullStatement = match.value.trim(),
                type = match.groupValues[1],
                innerContent = match.groupValues[2],
                startIndex = match.range.first,
                endIndex = match.range.last
            )
        })

        val phpRegex = Regex("""\[\s*['"]text['"]\s*=>\s*.*?(?=\])\]""")
        buttons.addAll(phpRegex.findAll(content).map { match ->
            DetectedButton(
                fullStatement = match.value.trim(),
                type = "PHP_Array",
                innerContent = match.value,
                startIndex = match.range.first,
                endIndex = match.range.last
            )
        })

        val jsRegex = Regex("""\{\s*['"]?text['"]?\s*:.*?(?=\})\s*\}""")
        buttons.addAll(jsRegex.findAll(content).map { match ->
            DetectedButton(
                fullStatement = match.value.trim(),
                type = "JS_Object",
                innerContent = match.value,
                startIndex = match.range.first,
                endIndex = match.range.last
            )
        })

        return buttons.sortedBy { it.startIndex }
    }

    private fun readUri(uri: Uri, resolver: ContentResolver): String? {
        return try {
            resolver.openInputStream(uri)?.use { 
                it.bufferedReader().readText() 
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun getFileName(uri: Uri, resolver: ContentResolver): String? {
        var name: String? = null
        if (uri.scheme == "content") {
            try {
                resolver.query(uri, null, null, null, null)?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (index != -1) {
                            name = cursor.getString(index)
                        }
                    }
                }
            } catch (e: Exception) {
                // ignore
            }
        }
        if (name == null) {
            name = uri.path?.let { path ->
                val cut = path.lastIndexOf('/')
                if (cut != -1) path.substring(cut + 1) else path
            }
        }
        return name
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainScreen()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(viewModel: MainViewModel = viewModel()) {
    val context = LocalContext.current
    val pyFiles by viewModel.pyFiles.collectAsState()
    val outputUri by viewModel.outputUri.collectAsState()
    val isProcessing by viewModel.isProcessing.collectAsState()

    val filePickerLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        viewModel.addFiles(uris, context.contentResolver)
    }

    val folderPickerLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            viewModel.setOutputFolder(uri)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Bot Colorizer") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        },
        floatingActionButton = {
            if (pyFiles.isNotEmpty() && outputUri != null) {
                ExtendedFloatingActionButton(
                    onClick = {
                        viewModel.processAndSave(
                            context = context,
                            onSuccess = {
                                Toast.makeText(context, "Saved successfully!", Toast.LENGTH_LONG).show()
                                viewModel.clearFiles()
                            },
                            onError = { err ->
                                Toast.makeText(context, err, Toast.LENGTH_LONG).show()
                            }
                        )
                    },
                    icon = { Icon(Icons.Filled.Create, contentDescription = "Process") },
                    text = { Text("Process & Save") },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                )
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (isProcessing) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            }

            // Top Buttons
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                ElevatedButton(
                    onClick = { filePickerLauncher.launch("*/*") },
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Select Bot Scripts")
                }
                
                ElevatedButton(
                    onClick = { folderPickerLauncher.launch(null) },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Filled.Folder, contentDescription = null, modifier = Modifier.padding(end = 4.dp))
                    Text(if (outputUri != null) "Folder Selected" else "Select Output")
                }
            }

            if (pyFiles.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        "No scripts selected.\nTap 'Select Bot Scripts' to start.",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(pyFiles, key = { it.uri.toString() }) { file ->
                        FileCard(file = file, viewModel = viewModel)
                    }
                }
            }
        }
    }
}

@Composable
fun FileCard(file: PyFile, viewModel: MainViewModel) {
    var expanded by remember { mutableStateOf(false) }

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { expanded = !expanded }
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(text = file.name, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        text = "Detected Buttons: ${file.buttons.size}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Icon(
                    imageVector = if (expanded) Icons.Filled.KeyboardArrowUp else Icons.Filled.KeyboardArrowDown,
                    contentDescription = "Toggle"
                )
            }

            AnimatedVisibility(visible = expanded) {
                Column(modifier = Modifier.padding(16.dp)) {
                    if (file.buttons.isNotEmpty()) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically, 
                            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
                        ) {
                            Text("Set All to:", style = MaterialTheme.typography.labelLarge, modifier = Modifier.weight(1f))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf("success", "primary", "danger", null).forEach { color ->
                                    SmallColorChip(color = color) {
                                        viewModel.setGlobalFileColor(file.uri, color)
                                    }
                                }
                            }
                        }

                        file.buttons.forEach { btn ->
                            ButtonConfigRow(
                                button = btn,
                                onColorSelect = { c -> viewModel.updateButtonColor(file.uri, btn.id, c) }
                            )
                        }
                    } else {
                        Text("No supported buttons detected in this file.", style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
    }
}

@Composable
fun ButtonConfigRow(button: DetectedButton, onColorSelect: (String?) -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(8.dp))
            .padding(12.dp)
    ) {
        Text(
            text = button.fullStatement,
            style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(modifier = Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val options = listOf(
                "success" to MaterialTheme.colorScheme.primary,
                "primary" to MaterialTheme.colorScheme.secondary,
                "danger" to MaterialTheme.colorScheme.error,
                null to MaterialTheme.colorScheme.outline
            )
            
            options.forEach { (colorName, _) ->
                FilterChip(
                    selected = button.selectedColor == colorName,
                    onClick = { onColorSelect(colorName) },
                    label = { Text(colorName?.capitalize() ?: "None") },
                    leadingIcon = if (button.selectedColor == colorName) {
                        { Icon(Icons.Filled.Check, contentDescription = null, modifier = Modifier.size(16.dp)) }
                    } else null
                )
            }
        }
    }
}

@Composable
fun SmallColorChip(color: String?, onClick: () -> Unit) {
    OutlinedButton(
        onClick = onClick,
        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
        modifier = Modifier.height(32.dp)
    ) {
        Text(color?.take(3)?.capitalize() ?: "None", style = MaterialTheme.typography.labelSmall)
    }
}

